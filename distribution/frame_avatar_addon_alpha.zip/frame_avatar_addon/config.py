from .constants import IGNORED

class default_config:
	#we spec
	min_uv_area_weight = 1e-6
	max_uv_area_weight = IGNORED