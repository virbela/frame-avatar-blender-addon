import bpy
from .helpers import (
	enum_descriptor, 
	get_named_entry, 
	require_named_entry, 
	frame_property_group, 
)
from .logging import log_writer as log
from .constants import MIRROR_TYPE, TARGET_UV_MAP

#Important notes
#	Regarding descriptions of properties, please see contribution note 1

#ISSUE-9: Not all properties have descriptions
#	Add descriptions for them
#	labels: needs-work

UV_ISLAND_MODES = enum_descriptor(

	#Tuple layout - see https://docs.blender.org/api/current/bpy.props.html#bpy.props.EnumProperty
	#(identifier, 			name, 				description,
	#	icon, 				number),

	#NOTE - Suspecting the number is not needed, also since we use our own object to represent these values we could have the long column last and get a more
	#compact and nice table.

	('UV_IM_MONOCHROME',	'Grayscale',		'This UV island will be channel packed to a grayscale segment of the atlas',
		'IMAGE_ZDEPTH',		0),

	('UV_IM_COLOR',			'Color',			'This UV island will end up on the color segment of the atlas',
		'COLOR',			1),

	('UV_IM_NIL',			'Nil UV island',	'This UV island will have zero area (unshaded)',
		'DOT',				2),

	('UV_IM_FROZEN',		'Frozen',			'This UV island will not be modified by the packer',
		'FREEZE',			3),
)


UV_MIRROR_AXIS = enum_descriptor(

	#Tuple layout - see https://docs.blender.org/api/current/bpy.props.html#bpy.props.EnumProperty
	#(identifier, 			name, 				description,
	#	icon, 				number),

	#NOTE - Suspecting the number is not needed, also since we use our own object to represent these values we could have the long column last and get a more
	#compact and nice table.

	('UV_MA_U',				'U',				'U (X) Axis',
		'EVENT_U',			0),

	('UV_MA_V',				'V',				'V (Y) Axis',
		'EVENT_V',			1),

)


UV_BAKE_MODE = enum_descriptor(

	#Tuple layout - see https://docs.blender.org/api/current/bpy.props.html#bpy.props.EnumProperty
	#(identifier, 			name, 				description,
	#	icon, 				number),

	#NOTE - Suspecting the number is not needed, also since we use our own object to represent these values we could have the long column last and get a more
	#compact and nice table.

	('UV_BM_REGULAR',		'Regular',			'This is a regular, non mirrored, bake target',
		'OBJECT_DATA',		0),

	('UV_BM_MIRRORED',		'Mirrored',			'This bake target will be mirrored upon another target along the U axis',
		'MOD_MIRROR',		1),
)


UV_TARGET_CHANNEL = enum_descriptor(

	#Tuple layout - see https://docs.blender.org/api/current/bpy.props.html#bpy.props.EnumProperty
	#(identifier, 			name, 				description,
	#	icon, 				number),

	#NOTE - Suspecting the number is not needed, also since we use our own object to represent these values we could have the long column last and get a more
	#compact and nice table.

	('UV_TARGET_NIL',		'Unassigned',			'UV island has not yet been assigned an atlas channel',
		'DOT',				0),

	('UV_TARGET_COLOR',		'Color channel',		'UV island will be placed in the color channel',
		'COLOR',			1),

	('UV_TARGET_R',			'Red channel',			'UV island will be placed in the red channel',
		'EVENT_R',			2),

	('UV_TARGET_G',			'Green channel',		'UV island will be placed in the green channel',
		'EVENT_G',			3),

	('UV_TARGET_B',			'Blue channel',			'UV island will be placed in the blue channel',
		'EVENT_B',			4),
)

def update_atlas(self, context):
	# when atlas is set, also set the uv_channel
	if 'red' in self.intermediate_atlas.name:
		self.uv_target_channel = 'UV_TARGET_R'
	elif 'green' in self.intermediate_atlas.name:
		self.uv_target_channel = 'UV_TARGET_G'
	elif 'blue' in self.intermediate_atlas.name:
		self.uv_target_channel = 'UV_TARGET_B'
	elif 'color' in self.intermediate_atlas.name:
		self.uv_target_channel = 'UV_TARGET_COLOR'
	else:
		self.uv_target_channel = 'UV_TARGET_NIL'

class BakeVariant(frame_property_group):
	name: 					bpy.props.StringProperty(name="Variant name", default='Untitled variant')
	image:					bpy.props.PointerProperty(name="Image texture", type=bpy.types.Image)
	uv_map:					bpy.props.StringProperty(name="UV Map")

	workmesh:				bpy.props.PointerProperty(name='Work mesh', type=bpy.types.Object)

	#NOTE - we are not caring about target channel right now - we instead use intermediate_atlas
	uv_target_channel:				bpy.props.EnumProperty(items=tuple(UV_TARGET_CHANNEL), name="UV target channel", default=0)
	intermediate_atlas:				bpy.props.PointerProperty(name='Intermediate atlas', type=bpy.types.Image, update=update_atlas)



#FUTURE - we may want to use work meshes as the container for each bake target in the future so that we can easier deal with selections but now we want to just get the current structure working all the way
class BakeTarget(frame_property_group):

	name: 					bpy.props.StringProperty(name = "Bake target name", default='Untitled bake target')

	object_name: 			bpy.props.StringProperty(
		name = 					"Object name",
		description = 			"The object that is used for this bake target.\n"
								"Once selected it is possible to select a specific shape key",
	)

	# source info
	source_object:					bpy.props.PointerProperty(name='Source object', type=bpy.types.Object)
	shape_key_name: 				bpy.props.StringProperty(name="Shape key")

	uv_area_weight: 				bpy.props.FloatProperty(
										name="UV island area weight", default=1.0,
										min=0.0, max=1.0
									)

	bake_mode:						bpy.props.EnumProperty(items=tuple(UV_BAKE_MODE), name="UV bake mode", default=0)

	uv_mirror_axis:					bpy.props.EnumProperty(items=tuple(UV_MIRROR_AXIS), name="UV mirror axis", default=0)

	mirror_source:					bpy.props.IntProperty(name='Bake target used for mirror')
	uv_mirror_options_expanded:		bpy.props.BoolProperty(name="UV mirror options expanded", default=True)

	#geom_mirror_axis:				bpy.props.EnumProperty(items=tuple(GEOMETRY_MIRROR_AXIS), name="Geometry mirror axis", default=0)		#MAYBE-LATER

	uv_mode:						bpy.props.EnumProperty(items=tuple(UV_ISLAND_MODES), name="UV island mode", default=0)
	atlas:							bpy.props.PointerProperty(name="Atlas image", type=bpy.types.Image)
	# ↑ This is used for storing the automatic choice as well as the manual (frozen) one

	#TBD - use this? - yes we need UV map for when rescaling from source
	source_uv_map:					bpy.props.StringProperty(name="UV map", default=TARGET_UV_MAP)


	#Variants
	multi_variants:					bpy.props.BoolProperty(name="Multiple variants", default=False)
	variant_collection:				bpy.props.CollectionProperty(type = BakeVariant)
	selected_variant:				bpy.props.IntProperty(name = "Selected bake variant", default = -1)

	def get_object(self):
		return get_named_entry(bpy.data.objects, self.object_name)

	def require_object(self):
		return require_named_entry(bpy.data.objects, self.object_name)

	def get_atlas(self):
		return get_named_entry(bpy.data.images, self.atlas)

	def require_atlas(self):
		return require_named_entry(bpy.data.images, self.atlas)

	@property
	def shortname(self):
		if self.object_name:
			if self.shape_key_name:
				return self.shape_key_name
			else:
				return self.object_name
		return 'untitled'


	def get_mirror_type(self, ht):
		find_id = ht.get_bake_target_index(self)
		for mirror in ht.bake_target_mirror_collection:
			if find_id == mirror.primary:
				return mirror, MIRROR_TYPE.PRIMARY
			elif find_id == mirror.secondary:
				return mirror, MIRROR_TYPE.SECONDARY

		return None, None


	#TBD should we use the name here or the identifier?
	# def get_bake_scene_name(self):
	# 	return self.identifier

	#NOTE we should probably deprecate this in favor of iter_variants
	# this doesn't yield anything if there are no variants
	def iter_bake_scene_variants(self):
		prefix = self.name # self.get_bake_scene_name()
		if self.multi_variants:
			for variant in self.variant_collection:
				yield f'{prefix}.{variant.name}', variant


	#TODO - use a helper function for creating names
	def iter_variants(self):
		prefix = self.name # self.get_bake_scene_name()
		for variant in self.variant_collection:
			if self.multi_variants:
				yield f'{prefix}.{variant.name}', variant
			else:
				yield f'{prefix}', variant


	def iter_bake_scene_variant_names(self):
		prefix = self.name # self.get_bake_scene_name()
		if self.multi_variants:
			for variant in self.variant_collection:
				yield f'{prefix}.{variant.name}'
		else:
			yield prefix


class BakeTargetReference(frame_property_group):
	target:					bpy.props.IntProperty(name='Bake target identifier', default=-1)

class BakeGroup(frame_property_group):
	name: 					bpy.props.StringProperty(name="Group name", default='Untitled group')
	members:				bpy.props.CollectionProperty(type = BakeTargetReference)
	selected_member:		bpy.props.IntProperty(name = "Selected bake target", default = -1)

class BakeTargetMirrorEntry(frame_property_group):
	#Here I wanted to use PointerProperty but they don't really act as the name implies. See contribution note 7 for more details.
	primary: 				bpy.props.IntProperty(name='Primary bake target identifier', default=-1)
	secondary: 				bpy.props.IntProperty(name='Secondary bake target identifier', default=-1)

def update_atlas_size(self, context):
	atlas_images = [im for im in bpy.data.images if 'atlas_intermediate' in im.name]
	if atlas_images:
		ats = self.atlas_size
		for at in atlas_images:
			at.generated_color = (1.0, 1.0, 1.0, 1.0)
			if tuple(at.size) != (ats, ats):
				log.info(f"Resizing '{at.name}' from {tuple(at.size)} to {(ats, ats)}")
				at.scale(ats, ats)
				at.update()

class EffectProperty(frame_property_group):
	name: 					bpy.props.StringProperty(name="Effect Name", default='Untitled Effect')
	target:					bpy.props.IntProperty(name='Effect identifier', default=-1)

	parent_shapekey: 		bpy.props.StringProperty(
								name="Parent Shapekey",
								description="Shape key used as the relative key for this effect"
							)
	effect_shapekey:		bpy.props.StringProperty(
								name="Effect Shapekey",
								description="Shape key with the final effect"
							)

class HomeomorphicProperties(frame_property_group):

	### Bake targets ###

	#Note that we use -1 to indicate that nothing is selected for integer selections
	effect_collection: 					bpy.props.CollectionProperty(type = EffectProperty)
	selected_effect: 					bpy.props.IntProperty(name = "Selected effect", default = -1)

	bake_target_collection: 			bpy.props.CollectionProperty(type = BakeTarget)
	selected_bake_target: 				bpy.props.IntProperty(name = "Selected bake target", default = -1)

	bake_target_mirror_collection: 		bpy.props.CollectionProperty(type = BakeTargetMirrorEntry)
	selected_bake_target_mirror: 		bpy.props.IntProperty(name = "Selected mirror entry", default = -1)

	bake_group_collection: 				bpy.props.CollectionProperty(type = BakeGroup)
	selected_bake_group: 				bpy.props.IntProperty(name = "Selected bake group", default = -1)

	source_object: 						bpy.props.StringProperty(name="Object name")

	### Atlas,textures, paint assist ###
	atlas_size: 						bpy.props.IntProperty(name="Atlas size", default = 4096, update=update_atlas_size)
	color_percentage:					bpy.props.FloatProperty(name="Atlas color region percentage", default = 25.0)
	painting_size:						bpy.props.IntProperty(name="Hand paint texture size", default = 1024)
	select_by_atlas_image:				bpy.props.PointerProperty(name='Match atlas', type=bpy.types.Image)

	### Export options
	denoise: 							bpy.props.BoolProperty(name="Denoise Atlas", default=False)
	export_atlas: 						bpy.props.BoolProperty(name="Export Atlas", default=True)
	export_glb: 						bpy.props.BoolProperty(name="Export GLB", default=True)
	export_animation: 					bpy.props.BoolProperty(name="Export Animation", default=True)

	def get_selected_effect(self):
		if self.selected_effect:
			return self.effect_collection[self.selected_effect]

	def get_selected_bake_target(self):
		if self.selected_bake_target != -1:
			return self.bake_target_collection[self.selected_bake_target]

	def get_selected_bake_group(self):
		if self.selected_bake_group != -1:
			return self.bake_group_collection[self.selected_bake_group]

	def require_selected_bake_target(self):
		if candidate := self.get_selected_bake_target():
			return candidate
		else:
			raise Exception()	#TODO - proper exception

	def get_selected_mirror(self):
		if self.selected_bake_target_mirror != -1:
			return self.bake_target_mirror_collection[self.selected_bake_target_mirror]

	def require_selected_mirror(self):
		if candidate := self.get_selected_mirror():
			return candidate
		else:
			raise Exception()	#TODO - proper exception

	def get_bake_target_index(self, target):
		for index, bt in enumerate(self.bake_target_collection):
			if bt == target:	# note: We can't use identity comparison due to internal deferring in blender
				return index

		return -1

	def get_bake_target_by_identifier(self, identifier):
		for bt in self.bake_target_collection:
			if bt.identifier == identifier:
				return bt

	def require_bake_target_by_identifier(self, identifier):
		if candidate := self.get_bake_target_by_identifier(identifier):
			return candidate
		else:
			#TODO - proper exception
			raise Exception()


class UIStateProperty(frame_property_group):
	workflow_introduction_visible: 			bpy.props.BoolProperty(default=True)
	workflow_bake_targets_visible: 			bpy.props.BoolProperty(default=True)
	workflow_work_meshes_visible: 			bpy.props.BoolProperty(default=False)
	workflow_texture_atlas_visible: 		bpy.props.BoolProperty(default=False)
	workflow_work_materials_visible: 		bpy.props.BoolProperty(default=False)
	workflow_baking_visible: 				bpy.props.BoolProperty(default=False)
	workflow_helpers_visible: 				bpy.props.BoolProperty(default=False)