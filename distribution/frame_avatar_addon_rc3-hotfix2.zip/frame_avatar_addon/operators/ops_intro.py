from ..helpers import require_bake_scene


def setup_bake_scene(operator, context, ht):
	require_bake_scene(context)
